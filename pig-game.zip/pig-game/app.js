

var scores, roundScore, activePlayer;
scores= [0,0];
roundScore= 0;
activePlayer= 0;
totalScore =0;
winScore=50;


document.getElementById('score-0').textContent=0;
document.getElementById('score-1').textContent=0;
document.getElementById('current-0').textContent=0;
document.getElementById('current-1').textContent=0;
setValueBtn = document.querySelector('.btn-set-value');
console.log(setValueBtn);
function btn() {

}
/*
document.querySelector('.btn-roll').addEventListener('click',btn);

*/

document.querySelector('.btn-roll').addEventListener('click', function(){
  //Random no.
  var dice= Math.floor(Math.random() *6) +1;
  //Display Dice Number
  var diceDOM= document.querySelector('.dice');
  diceDOM.style.display= 'block';
  diceDOM.src= 'dice-' +dice +'.png';
  //console.log(dice);
  //updating round score if dice != 1

  if(dice !==1)
  {
    roundScore +=dice;

    document.querySelector('#current-' + activePlayer).textContent=roundScore;
  }
  else{

    activePlayer ===0 ? activePlayer=1 :activePlayer= 0;
    roundScore=0;

    document.getElementById('current-0').textContent='0';
    document.getElementById('current-1').textContent='0';

    //document.querySelector('.player-0-panel').classList.remove('active');
    //document.querySelector('.player-1-panel').classList.add('active');

    document.querySelector('.player-0-panel').classList.toggle('active');
    document.querySelector('.player-1-panel').classList.toggle('active');

    document.querySelector('.dice').style.display='none';
  }



});

document.querySelector('.btn-hold').addEventListener('click', function(){
 scores[activePlayer] +=roundScore;
 console.log(scores[activePlayer]);
 if(scores[activePlayer]<winScore){
   document.getElementById('current-' + activePlayer).textContent='0';
   document.querySelector('#score-' + activePlayer).textContent=scores[activePlayer];
   activePlayer ===0 ? activePlayer=1 :activePlayer= 0;
   roundScore=0;
   document.querySelector('.player-0-panel').classList.toggle('active');
   document.querySelector('.player-1-panel').classList.toggle('active');

 }
  else{
    document.querySelector('#name-' + activePlayer).textContent= 'Winner';
    document.getElementById('current-' + activePlayer).textContent='0';
    document.querySelector('#score-' + activePlayer).textContent=scores[activePlayer];
  }


});

document.querySelector('.btn-new').addEventListener('click', function(){
  document.getElementById('current-0').textContent='0';
  document.querySelector('#score-0').textContent='0';
  document.getElementById('current-1').textContent='0';
  document.querySelector('#score-1').textContent='0';
  document.querySelector('#name-' + activePlayer).textContent= 'Player 1';
  document.querySelector('.player-0-panel').classList.toggle('active');
  roundScore=0;
  scores=[0,0];
  activePlayer=0;
  document.querySelector('.player-0-panel').classList.toggle('active');

});

document.querySelector('.btn-set-value').addEventListener('click',function(){
  inputValue=document.querySelector('.input-value');
  if(inputValue.value!==null){
      winScore= inputValue.value;
  }
});

/*
function getWinScore(){
	return .innerText;
}
*/
/*
setValueBtn.addEventListener('click', ()=>{

})
*/
